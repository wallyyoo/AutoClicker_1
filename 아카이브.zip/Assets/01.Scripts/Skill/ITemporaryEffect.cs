using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ITemporaryEffect
{
    void EndEffect(GameObject caster);
}
