﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalStats : MonoBehaviour
{
    // 아이템에 붙어있는 능력치 + 스킬에 붙어있는 능력치 + 업그래이드시킨 능력치
    public void FinalAttackPower()
    {

    }
    
    public void FinalCitiDamage()
    {

    }

    public void FinalCitiChance()
    {

    }

    public void FinalAutoSpeed()
    {

    }

    public void FianlHp()
    {

    }

    public void FianlMp()
    {

    }


    // 골드 획득량 래밸에 따른 골드 획득량 증가
    public void AddGold()
    {

    }

    // 업그레이드나 아이템 구매 시 골드 차감
    public void SubGold()
    {

    }
}
